#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// function to get matrix elements from a file, indicated by the filename
double **readmatrix(size_t *rows, size_t *cols, const char *filename)
{
    if(rows == NULL || cols == NULL || filename == NULL)
        return NULL;

    *rows = 0;
    *cols = 0;

    FILE *fp = fopen(filename, "r");

    if (fp == NULL)
    {
        fprintf(stderr, "could not open %s: %s\n", filename, strerror(errno));
        return NULL;
    }

    double **matrix = NULL, **tmp;

    char line[1024];

    while (fgets(line, sizeof line, fp))
    {
        if (*cols == 0)
        {
            // determine the size of the columns based on
            // the first row
            char *scan = line;
            double dummy;
            int offset = 0;
            while(sscanf(scan, "%lf%n", &dummy, &offset) == 1)
            {
                scan += offset;
                (*cols)++;
            }
        }

        tmp = (double **)realloc(matrix, (*rows + 1) * sizeof *matrix);

        if (tmp == NULL)
        {
            fclose(fp);
            return matrix; // return all you've parsed so far
        }

        matrix = tmp;

        matrix[*rows] = (double *)calloc(*cols, sizeof *matrix[*rows]);

        if (matrix[*rows] == NULL)
        {
            fclose(fp);
            if(*rows == 0) // failed in the first row, free everything
            {
                fclose(fp);
                free(matrix);
                return NULL;
            }

            return matrix; // return all you've parsed so far
        }

        int offset = 0;
        char *scan = line;
        for (size_t j = 0; j < *cols; ++j)
        {
            if (sscanf(scan, "%lf%n", matrix[*rows] + j, &offset) == 1)
                scan += offset;
            else
                matrix[*rows][j] = 0; // could not read, set cell to 0
        }

        // incrementing rows
        (*rows)++;
    }

    fclose(fp);

    return matrix;
}



// function to display the matrix
void displaymatrix(double **matrix, int row, int column) {

   printf("\nMatrix (%d x %d):\n", row, column);
   for (int i = 0; i < row; ++i) {
      for (int j = 0; j < column; ++j) {
         printf("%-3lf ", matrix[i][j]);
         if (j == column - 1)
            printf("\n");
      }
   }
}


// allocate 2D array
double **allocate_2D_array(int r, int c)
{
    int i, j;
 
    double** arr = (double**)malloc(r * sizeof(double*));
    for (i = 0; i < r; i++)
        arr[i] = (double*)malloc(c * sizeof(double));
 
    // Note that arr[i][j] is same as *(*(arr+i)+j)
    for (i = 0; i < r; i++)
        for (j = 0; j < c; j++)
            arr[i][j] = 0; // OR *(*(arr+i)+j) = 0
 
   return arr;
}


// random assign values to 2D array
void random_2D_array(double **arr, int r, int c)
{
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            arr[i][j] = (double) rand()/RAND_MAX;
}


void free_2D_array(double **arr, int r) {
    /* Code for further processing and free the
       dynamically allocated memory */
    for (int i = 0; i < r; i++)
        free(arr[i]);
 
    free(arr);
}


// function to multiply two matrices
void multiplyMatrices(double **first,
                      double **second,
                      double **result,
                      double r1, int c1, 
                      double r2, int c2) {

   // Initializing elements of matrix mult to 0.
   for (int i = 0; i < r1; ++i) {
      for (int j = 0; j < c2; ++j) {
         result[i][j] = 0;
      }
   }

   // Multiplying first and second matrices and storing it in result
   for (int i = 0; i < r1; ++i) {
      for (int j = 0; j < c2; ++j) {
         for (int k = 0; k < c1; ++k) {
            result[i][j] += first[i][k] * second[k][j];
         }
      }
   }
}


// the main function
int main() {
   int r1, c1, r2, c2;
   size_t cols, rows;

   // read Matrix A from file
   // alternatively use random_2D_array to assgin random values to the matrix (see below)
   // r1 = 1000; 
   // c1 = 1000;
   // double **matrix_A = allocate_2D_array(r1, c1);
   // random_2D_array(matrix_A, r1, c1);
   double **matrix_A = readmatrix(&rows, &cols, "./data/file_A.dat");
   r1 = (int)rows; c1 = (int)cols;
   
   // read Matrix B from file
   double **matrix_B = readmatrix(&rows, &cols, "./data/file_B.dat");
   r2 = (int)rows; c2 = (int)cols;

   // allocate memory for Matrix C
   int r3 = r1, c3 = c2;
   double **matrix_C = allocate_2D_array(r1, c2);

   displaymatrix(matrix_A, r1, c1);
   displaymatrix(matrix_B, r2, c2);
   
   // multiply two matrices.
   multiplyMatrices(matrix_A, matrix_B, matrix_C, r1, c1, r2, c2);

   // display the result
   displaymatrix(matrix_C, r3, c3);

   free_2D_array(matrix_A, r1);
   free_2D_array(matrix_B, r2);
   free_2D_array(matrix_C, r3);

   return 0;
}